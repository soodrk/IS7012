﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CoreCrud1.Models;

namespace CoreCrud1.Models
{
    public class CoreCrud1Context : DbContext
    {
        public CoreCrud1Context (DbContextOptions<CoreCrud1Context> options)
            : base(options)
        {
        }

        public DbSet<CoreCrud1.Models.Country> Countries { get; set; }

        public DbSet<CoreCrud1.Models.Destination> Destination { get; set; }
    }
}
