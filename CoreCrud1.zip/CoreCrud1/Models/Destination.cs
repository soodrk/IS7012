﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreCrud1.Models
{
    public class Destination
    {
        public int Id { get; set; }
        public string SourceCountry { get; set; }
        public string DestinationCountry { get; set; }
        public int DaysofStay { get; set; }
        public int BudgetAmount { get; set; }
        public int CountryID { get; set; }
        public Country Country { get; set; }
    }
}
