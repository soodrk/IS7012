﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreCrud3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace CoreCrud3.Pages
{
    public class IndexModel : PageModel
    {
        public CoreCrud3Context _context;
        public int SelectedAsDestinationCountryMaximumTimes;
        public int SelectedAsSourceCountryMaximumTimes;
        public int DaysOfTravelToBePlanned;

        public IndexModel(CoreCrud3Context context)
        {
            _context = context;
        }
        public void OnGet()
        {
           /** SelectedAsDestinationCountryMaximumTimes = _context.Destination
                                                       .Where(x => x.DestinationCountry !=null)
                                                  .Count();
            SelectedAsSourceCountryMaximumTimes = _context.Destination
                                                   .Where(x => x.DaysofStay != null)
                                                  .Count();


            DaysOfTravelToBePlanned = _context.Destination
                                                  .Where(x => x.DaysofStay != null)
                                                  .Count(); **/
        }
    }
}
