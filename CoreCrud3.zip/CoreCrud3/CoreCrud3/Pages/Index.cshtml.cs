﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreCrud3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace CoreCrud3.Pages
{
    public class IndexModel : PageModel
    {
        public CoreCrud3Context _context;

        public IndexModel(CoreCrud3Context context)
        {
            _context = context;
        }

        [BindProperty]
        public int CountofDestinations { get; set; }
        [BindProperty]
        public int CountofCountries { get; set; }
        public void OnGet()
        {
           CountofDestinations = _context.Destination.Count();
           CountofCountries = _context.Country.Count();
            
        }
    }
}
