﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CoreCrud3.Models
{
    public class Destination
    {
        
        public int Id { get; set; }
        public string SourceCountry { get; set; }
        public string DestinationCountry { get; set; }
        public DateTime DateofTravel{get;set;}
        public bool NeedsInsurance { get; set; }
        public int? DaysofStay { get; set; }
        public decimal BudgetAmount { get; set; }
        public int CountryID { get; set; }
        public Country Country { get; set; }
    

    }
}
