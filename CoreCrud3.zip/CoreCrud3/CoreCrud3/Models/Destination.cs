﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoreCrud3.Models
{
    public class Destination
    {

        [Required]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide a Source Country Name")]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "2 - 30 characters only")]
        [Display(Name = "Source Country")]
        [DataType(DataType.Text)]
        public string SourceCountry { get; set; }

        [Required(ErrorMessage = "Please provide a Destination Country Name")]
        [Display(Name = "Destination Country")]
        [DataType(DataType.Text)]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "2 - 30 characters only")]
        public string DestinationCountry { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date of Travel")]
        [CustomValidation(typeof(Destination), "IsValid")]
        public DateTime DateofTravel{get;set;}

        [NotMapped]
        [Display(Name = "Needs Insurance")]
        public bool NeedsInsurance { get; set; }

        [Range(0, 30, ErrorMessage = "We plan trips for maximum of 30 days only")]
        [Display(Name = "Days of Stay")]
        public int? DaysofStay { get; set; }

        [CustomValidation(typeof(Destination), "BudgetAmountValidation")]
        [Display(Name = "Budget Amount")]
        [DataType(DataType.Currency)]
        public decimal BudgetAmount { get; set; }

        public int CountryID { get; set; }
        public Country Country { get; set; }


        public static ValidationResult IsValid(DateTime value, ValidationContext validationContext)
        {
            if (value.GetType() == typeof(DateTime) && value > DateTime.Now)
                return ValidationResult.Success;
            return new ValidationResult("Date Invalid");
        }

        public static ValidationResult BudgetAmountValidation(int value, ValidationContext validationContext)
        {
            if (value > 0)
                return ValidationResult.Success;
            return new ValidationResult("Amount cannot be less than Zero!");
        }

    }


}
