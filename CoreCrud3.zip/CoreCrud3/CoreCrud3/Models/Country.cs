﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreCrud3.Models
{
    public class Country
    {
        public int ID { get; set; }
        public int CountryId { get; set; }
        public string Location { get; set; }
        public string Language { get; set; }
        public ICollection<Destination> Destinations { get; set; }


    }
}
