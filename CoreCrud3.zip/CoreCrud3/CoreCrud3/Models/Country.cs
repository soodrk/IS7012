﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CoreCrud3.Models
{
    public class Country
    {
        public int ID { get; set; }
        public int CountryId { get; set; }


        [Required(ErrorMessage = "Please provide a valid Country Name")]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "2 - 30 characters only")]
        public string Location { get; set; }

        [StringLength(30, MinimumLength = 2, ErrorMessage = "2 - 30 characters only")]
        public string Language { get; set; }
        public ICollection<Destination> Destinations { get; set; }


    }
}
