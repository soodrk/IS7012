﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreCrud.Models
{
    public class Destination
    {
        public int Id { get; set; }
        public string SourceCountry { get; set; }
        public string DestinationCountry { get; set; }
        public int DaysofStay { get; set; }
        public int BudgetAmount { get; set; }
        public int CountryID { get; set; }
        public Countries Countries { get; set; }
    }


    public class Countries
    {
        public int CountryId { get; set; }
        public string Location { get; set; }
        public string EstimatedExpenses { get; set; }
        public ICollection<Destination> Destination { get; set; }
    }
}
